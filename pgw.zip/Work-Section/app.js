

// Flip functionality
document.querySelectorAll('.learn-more').forEach(button => {
    button.addEventListener('click', function() {
        this.closest('.project-card').classList.add('flipped');
    });
});

document.querySelectorAll('.btn-close-card').forEach(button => {
    button.addEventListener('click', function() {
        this.closest('.project-card').classList.remove('flipped');
    });
});


// <!-- Smooth Scrolling -->

    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });


    // video-section-script


   
    document.addEventListener('DOMContentLoaded', function() {
        // Get all video containers
        const videoContainers = document.querySelectorAll('.video-container');
        const lightbox = document.querySelector('.video-lightbox');
        const lightboxVideo = lightbox.querySelector('video');
        const lightboxTitle = lightbox.querySelector('.lightbox-title');
        const closeLightbox = lightbox.querySelector('.close-lightbox');

        // Initialize each video container
        videoContainers.forEach(container => {
            const video = container.querySelector('video');
            const overlay = container.querySelector('.video-overlay');
            const playButton = overlay.querySelector('.play-button');
            const controls = container.querySelector('.video-controls');
            const playPauseBtn = controls.querySelector('.play-pause');
            const progressBar = controls.querySelector('.progress-bar');
            const timeDisplay = controls.querySelector('.time-display');
            const muteBtn = controls.querySelector('.mute');
            const volumeSlider = controls.querySelector('.volume-slider');
            const fullscreenBtn = controls.querySelector('.fullscreen');
            const videoTitle = overlay.querySelector('.video-title').textContent;

            // Play/pause functionality
            playButton.addEventListener('click', function(e) {
                e.stopPropagation();
                container.classList.add('playing');
                video.play();
                playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
            });

            playPauseBtn.addEventListener('click', function() {
                if (video.paused) {
                    video.play();
                    this.innerHTML = '<i class="fas fa-pause"></i>';
                } else {
                    video.pause();
                    this.innerHTML = '<i class="fas fa-play"></i>';
                }
            });

            // Update progress bar
            video.addEventListener('timeupdate', function() {
                const progress = (video.currentTime / video.duration) * 100;
                progressBar.style.width = progress + '%';
                
                // Update time display
                const currentMinutes = Math.floor(video.currentTime / 60);
                const currentSeconds = Math.floor(video.currentTime % 60).toString().padStart(2, '0');
                const durationMinutes = Math.floor(video.duration / 60);
                const durationSeconds = Math.floor(video.duration % 60).toString().padStart(2, '0');
                
                timeDisplay.textContent = `${currentMinutes}:${currentSeconds} / ${durationMinutes}:${durationSeconds}`;
            });

            // Click on progress bar to seek
            const progressContainer = controls.querySelector('.progress-container');
            progressContainer.addEventListener('click', function(e) {
                const rect = this.getBoundingClientRect();
                const pos = (e.pageX - rect.left) / this.offsetWidth;
                video.currentTime = pos * video.duration;
            });

            // Mute/unmute
            muteBtn.addEventListener('click', function() {
                video.muted = !video.muted;
                this.innerHTML = video.muted ? 
                    '<i class="fas fa-volume-mute"></i>' : 
                    '<i class="fas fa-volume-up"></i>';
                volumeSlider.value = video.muted ? 0 : video.volume;
            });

            // Volume control
            volumeSlider.addEventListener('input', function() {
                video.volume = this.value;
                video.muted = (this.value == 0);
                muteBtn.innerHTML = (this.value == 0) ? 
                    '<i class="fas fa-volume-mute"></i>' : 
                    '<i class="fas fa-volume-up"></i>';
            });

            // Fullscreen in lightbox
            fullscreenBtn.addEventListener('click', function() {
                lightbox.classList.add('active');
                lightboxVideo.src = video.querySelector('source').src;
                lightboxTitle.textContent = videoTitle;
                lightboxVideo.play();
            });

            // Click on video container to play/pause
            container.addEventListener('click', function() {
                if (video.paused) {
                    video.play();
                    playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
                } else {
                    video.pause();
                    playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
                }
            });

            // Reset video when ended
            video.addEventListener('ended', function() {
                container.classList.remove('playing');
                video.currentTime = 0;
                playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
            });
        });

        // Close lightbox
        closeLightbox.addEventListener('click', function() {
            lightbox.classList.remove('active');
            lightboxVideo.pause();
            lightboxVideo.currentTime = 0;
        });

        // Close lightbox when clicking outside
        lightbox.addEventListener('click', function(e) {
            if (e.target === lightbox) {
                lightbox.classList.remove('active');
                lightboxVideo.pause();
                lightboxVideo.currentTime = 0;
            }
        });
    });
